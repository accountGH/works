window.onload = function () {
	



	$( "#burger" ).click(function() {
	  $(this).toggleClass('active');
	  $('.header-menu').toggleClass('active');
	});

	$('.list a').click(function() {
		// $(this).toggleClass('color');
		$('#burger').toggleClass('active');
		$('.header-menu').toggleClass('active');
	})

	



}